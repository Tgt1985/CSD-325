from django.apps import AppConfig


class MyworldConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'myworld'
